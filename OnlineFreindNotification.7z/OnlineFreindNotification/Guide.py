uimessenger.py

# Add:

import player
from ui_wrapper import _ui
import chr, chrmgr, dbg


# Search:
	def OnLogin(self, groupIndex, key, name=None):
		if not name:
			name = key
		group = self.groupList[groupIndex]
		member = self.__AddList(groupIndex, key, name)
		member.SetName(name)
		member.Online()
		self.OnRefreshList()
		
# Add/Change to:
	def OnLogin(self, groupIndex, key, name=None):
		if not name:
			name = key
		group = self.groupList[groupIndex]
		member = self.__AddList(groupIndex, key, name)
		member.SetName(name)
		member.Online()
		self.OnRefreshList()

		if name != player.GetName():
			vid = chrmgr.GetVID(name)
			if vid:
				chr.SelectInstance(vid)
				self.Notificaton = _ui().PopupNotification("%s ���� ����!" % name)# %s is online now!
				trace = chr.GetRace()
				if trace:
					self.Notificaton.SetType(type = 3, race = trace)

***

pythoncharactermanagermodule.cpp

# // Search:
		{ "SetEmpireNameMode",			chrmgrSetEmpireNameMode,				METH_VARARGS },

# // Add:
		{ "GetVID",						chrmgrGetVID,							METH_VARARGS },

		
--

# // Search:
PyObject * chrmgrIsPossibleEmoticon(PyObject* poSelf, PyObject* poArgs)
{
	int nVID;
	if (!PyTuple_GetInteger(poArgs, 0, &nVID))
		return Py_BadArgument();

	CPythonCharacterManager & rkChrMgr = CPythonCharacterManager::Instance();
	int result = rkChrMgr.IsPossibleEmoticon(nVID >= 0 ? nVID : 0xffffffff);

	return Py_BuildValue("i", result);
}

# // Add:
PyObject * chrmgrGetVID(PyObject* poSelf, PyObject* poArgs)
{
	char * szName;
	if (!PyTuple_GetString(poArgs, 0, &szName))
		return Py_BadArgument();

	CPythonCharacterManager& rkChrMgr = CPythonCharacterManager::Instance();

	for (CPythonCharacterManager::CharacterIterator itor = rkChrMgr.CharacterInstanceBegin(); itor != rkChrMgr.CharacterInstanceEnd(); ++itor)
	{
		CInstanceBase* pInstance = *itor;
		if (!strcmp(szName, pInstance->GetNameString()))
			return Py_BuildValue("i", pInstance->GetVirtualID());
	}

	return Py_BuildValue("i", 0);
}
