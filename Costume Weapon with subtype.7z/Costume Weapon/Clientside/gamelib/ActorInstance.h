


class CActorInstance : public IActorInstance, public IFlyTargetableObject
{
	
	public:
	
		void AttachWeapon(DWORD dwItemIndex,DWORD dwParentPartIndex = CRaceData::PART_MAIN, DWORD dwPartIndex = CRaceData::PART_WEAPON);
		void AttachWeapon(DWORD dwParentPartIndex, DWORD dwPartIndex, CItemData * pItemData);
		#ifdef ENABLE_COSTUME_WEAPON
		void RemoveLeftHand(CItemData * pItemData);
		#endif
		[..]