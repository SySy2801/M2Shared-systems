void __SetWeaponPower(IAbstractPlayer& rkPlayer, DWORD dwWeaponID)
{
	DWORD minPower=0;
	DWORD maxPower=0;
	DWORD minMagicPower=0;
	DWORD maxMagicPower=0;
	DWORD addPower=0;
#ifdef ENABLE_COSTUME_WEAPON
	//DMG RESET BUG FIX
	dwWeaponID = rkPlayer.GetItemIndex(TItemPos(INVENTORY, c_Equipment_Weapon));
#endif
	CItemData* pkWeapon;
	
	if (CItemManager::Instance().GetItemDataPointer(dwWeaponID, &pkWeapon))
	{
		if (pkWeapon->GetType()==CItemData::ITEM_TYPE_WEAPON)
		{
			minPower=pkWeapon->GetValue(3);
			maxPower=pkWeapon->GetValue(4);
			minMagicPower=pkWeapon->GetValue(1);
			maxMagicPower=pkWeapon->GetValue(2);
			addPower=pkWeapon->GetValue(5);
		}
	}
#ifdef ENABLE_COSTUME_WEAPON
	DWORD dwItemIndex = rkPlayer.GetItemIndex(TItemPos(INVENTORY, c_Costume_Slot_Weapon));

	CItemData* pkCostumeWeapon;
	if (CItemManager::Instance().GetItemDataPointer(dwItemIndex, &pkCostumeWeapon))
	{
		if (pkCostumeWeapon->GetType() == CItemData::ITEM_TYPE_COSTUME && pkCostumeWeapon->GetWeaponType() == CItemData::COSTUME_WEAPON_SWORD ||
			pkCostumeWeapon->GetWeaponType() == CItemData::COSTUME_WEAPON_DAGGER || pkCostumeWeapon->GetWeaponType() == CItemData::COSTUME_WEAPON_BOW ||
			pkCostumeWeapon->GetWeaponType() == CItemData::COSTUME_WEAPON_TWO_HANDED || pkCostumeWeapon->GetWeaponType() == CItemData::COSTUME_WEAPON_BELL ||
			pkCostumeWeapon->GetWeaponType() == CItemData::COSTUME_WEAPON_FAN || pkCostumeWeapon->GetWeaponType() == CItemData::COSTUME_WEAPON_CLAW)
		{
			minPower += pkCostumeWeapon->GetValue(3);
			maxPower += pkCostumeWeapon->GetValue(4);
			minMagicPower += pkCostumeWeapon->GetValue(1);
			maxMagicPower += pkCostumeWeapon->GetValue(2);
			addPower += pkCostumeWeapon->GetValue(5);
		}
	}
#endif

	rkPlayer.SetWeaponPower(minPower, maxPower, minMagicPower, maxMagicPower, addPower);
}
