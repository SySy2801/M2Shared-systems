void CPythonItem::CreateItem(DWORD dwVirtualID, DWORD dwVirtualNumber, float x, float y, float z, bool bDrop)
{
	[..]
	if (bDrop)
	{
		z = CPythonBackground::Instance().GetHeight(x, y) + 10.0f;

		if (pItemData->GetType()==CItemData::ITEM_TYPE_WEAPON && 
			(pItemData->GetWeaponType() == CItemData::WEAPON_SWORD ||
		#ifdef ENABLE_COSTUME_WEAPON
			 pItemData->GetWeaponType() == CItemData::COSTUME_WEAPON_SWORD ||
		 #endif
			 pItemData->GetWeaponType() == CItemData::WEAPON_ARROW))
			bStabGround = true;

		bStabGround = false;
		pGroundItemInstance->bAnimEnded = false;
	}
	else
	{
		pGroundItemInstance->bAnimEnded = true;
	}

	[..]
}
