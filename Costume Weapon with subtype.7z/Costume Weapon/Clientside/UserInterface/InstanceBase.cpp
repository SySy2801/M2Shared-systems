DWORD CInstanceBase::GetWeaponType()
{

	DWORD dwWeapon = GetPart(CRaceData::PART_WEAPON);
	CItemData * pItemData;
	if (!CItemManager::Instance().GetItemDataPointer(dwWeapon, &pItemData))
		return CItemData::WEAPON_NONE;
#ifdef ENABLE_COSTUME_WEAPON
	if (pItemData->GetType() == CItemData::ITEM_TYPE_COSTUME)
		return pItemData->GetWeaponType() - CItemData::COSTUME_WEAPON_SWORD;
#endif
	return pItemData->GetWeaponType();
}
UINT CInstanceBase::__GetRefinedEffect(CItemData* pItem)
{
	DWORD refine = max(pItem->GetRefine() + pItem->GetSocketCount(), CItemData::ITEM_SOCKET_MAX_NUM) - CItemData::ITEM_SOCKET_MAX_NUM;
	switch (pItem->GetType())
	{
	case CItemData::ITEM_TYPE_WEAPON:
		__ClearWeaponRefineEffect();
		if (refine < 7)	//ÇöŔç Á¦·Ăµµ 7 ŔĚ»ó¸¸ ŔĚĆĺĆ®°ˇ ŔÖ˝Ŕ´Ď´Ů.
			return 0;
		switch (pItem->GetSubType())
		{
#ifdef ENABLE_COSTUME_WEAPON
		case CItemData::COSTUME_WEAPON_DAGGER:
#endif
		case CItemData::WEAPON_DAGGER:
			m_swordRefineEffectRight = EFFECT_REFINED + EFFECT_SMALLSWORD_REFINED7 + refine - 7;
			m_swordRefineEffectLeft = EFFECT_REFINED + EFFECT_SMALLSWORD_REFINED7_LEFT + refine - 7;
			break;
#ifdef ENABLE_COSTUME_WEAPON
		case CItemData::COSTUME_WEAPON_FAN:
#endif
		case CItemData::WEAPON_FAN:
			m_swordRefineEffectRight = EFFECT_REFINED + EFFECT_FANBELL_REFINED7 + refine - 7;
			break;
#ifdef ENABLE_COSTUME_WEAPON
		case CItemData::COSTUME_WEAPON_BELL:
#endif
		case CItemData::WEAPON_ARROW:
		case CItemData::WEAPON_BELL:
			m_swordRefineEffectRight = EFFECT_REFINED + EFFECT_SMALLSWORD_REFINED7 + refine - 7;
			break;
#ifdef ENABLE_COSTUME_WEAPON
		case CItemData::COSTUME_WEAPON_BOW:
#endif
		case CItemData::WEAPON_BOW:
			m_swordRefineEffectRight = EFFECT_REFINED + EFFECT_BOW_REFINED7 + refine - 7;
			break;
		default:
			m_swordRefineEffectRight = EFFECT_REFINED + EFFECT_SWORD_REFINED7 + refine - 7;
		}
		if (m_swordRefineEffectRight)
			m_swordRefineEffectRight = __AttachEffect(m_swordRefineEffectRight);
		if (m_swordRefineEffectLeft)
			m_swordRefineEffectLeft = __AttachEffect(m_swordRefineEffectLeft);
		break;
	case CItemData::ITEM_TYPE_ARMOR:
		__ClearArmorRefineEffect();
		if (refine < 7)	//ÇöŔç Á¦·Ăµµ 7 ŔĚ»ó¸¸ ŔĚĆĺĆ®°ˇ ŔÖ˝Ŕ´Ď´Ů.
			return 0;
		m_armorRefineEffect = EFFECT_BODYARMOR_REFINED7 + refine - 7;
		__AttachEffect(m_armorRefineEffect);
		break;
	}
	return 0;
}


void CInstanceBase::RefreshState(DWORD dwMotIndex, bool isLoop)
{
	DWORD dwPartItemID = m_GraphicThingInstance.GetPartItemID(CRaceData::PART_WEAPON);

	BYTE byItemType = 0xff;
	BYTE bySubType = 0xff;

	CItemManager & rkItemMgr = CItemManager::Instance();
	CItemData * pItemData;

	if (rkItemMgr.GetItemDataPointer(dwPartItemID, &pItemData))
	{
		byItemType = pItemData->GetType();
		bySubType = pItemData->GetWeaponType();
	}

	if (IsPoly())
	{
		SetMotionMode(CRaceMotionData::MODE_GENERAL);
	}
	else if (IsWearingDress())
	{
		SetMotionMode(CRaceMotionData::MODE_WEDDING_DRESS);
	}
	else if (IsHoldingPickAxe())
	{
		if (m_kHorse.IsMounting())
		{
			SetMotionMode(CRaceMotionData::MODE_HORSE);
		}
		else
		{
			SetMotionMode(CRaceMotionData::MODE_GENERAL);
		}
	}
	else if (CItemData::ITEM_TYPE_ROD == byItemType)
	{
		if (m_kHorse.IsMounting())
		{
			SetMotionMode(CRaceMotionData::MODE_HORSE);
		}
		else
		{
			SetMotionMode(CRaceMotionData::MODE_FISHING);
		}
	}
	else if (m_kHorse.IsMounting())
	{
		switch (bySubType)
		{
#ifdef ENABLE_COSTUME_WEAPON
		case CItemData::COSTUME_WEAPON_SWORD:
#endif
		case CItemData::WEAPON_SWORD:
			SetMotionMode(CRaceMotionData::MODE_HORSE_ONEHAND_SWORD);
			break;

#ifdef ENABLE_COSTUME_WEAPON
		case CItemData::COSTUME_WEAPON_TWO_HANDED:
#endif
		case CItemData::WEAPON_TWO_HANDED:
			SetMotionMode(CRaceMotionData::MODE_HORSE_TWOHAND_SWORD); // Only Warrior
			break;

#ifdef ENABLE_COSTUME_WEAPON
		case CItemData::COSTUME_WEAPON_DAGGER:
#endif
		case CItemData::WEAPON_DAGGER:
			SetMotionMode(CRaceMotionData::MODE_HORSE_DUALHAND_SWORD); // Only Assassin
			break;

#ifdef ENABLE_COSTUME_WEAPON
		case CItemData::COSTUME_WEAPON_FAN:
#endif
		case CItemData::WEAPON_FAN:
			SetMotionMode(CRaceMotionData::MODE_HORSE_FAN); // Only Shaman
			break;

#ifdef ENABLE_COSTUME_WEAPON
		case CItemData::COSTUME_WEAPON_BELL:
#endif
		case CItemData::WEAPON_BELL:
			SetMotionMode(CRaceMotionData::MODE_HORSE_BELL); // Only Shaman
			break;

#ifdef ENABLE_COSTUME_WEAPON
		case CItemData::COSTUME_WEAPON_BOW:
#endif
		case CItemData::WEAPON_BOW:
			SetMotionMode(CRaceMotionData::MODE_HORSE_BOW); // Only Shaman
			break;


		default:
			SetMotionMode(CRaceMotionData::MODE_HORSE);
			break;
		}
	}
	else
	{
		switch (bySubType)
		{
#ifdef ENABLE_COSTUME_WEAPON
		case CItemData::COSTUME_WEAPON_SWORD:
#endif
		case CItemData::WEAPON_SWORD:
			SetMotionMode(CRaceMotionData::MODE_ONEHAND_SWORD);
			break;

#ifdef ENABLE_COSTUME_WEAPON
		case CItemData::COSTUME_WEAPON_TWO_HANDED:
#endif
		case CItemData::WEAPON_TWO_HANDED:
			SetMotionMode(CRaceMotionData::MODE_TWOHAND_SWORD); // Only Warrior
			break;

#ifdef ENABLE_COSTUME_WEAPON
		case CItemData::COSTUME_WEAPON_DAGGER:
#endif
		case CItemData::WEAPON_DAGGER:
			SetMotionMode(CRaceMotionData::MODE_DUALHAND_SWORD); // Only Assassin
			break;


#ifdef ENABLE_COSTUME_WEAPON
		case CItemData::COSTUME_WEAPON_BOW:
#endif
		case CItemData::WEAPON_BOW:
			SetMotionMode(CRaceMotionData::MODE_BOW); // Only Assassin
			break;

#ifdef ENABLE_COSTUME_WEAPON
		case CItemData::COSTUME_WEAPON_FAN:
#endif
		case CItemData::WEAPON_FAN:
			SetMotionMode(CRaceMotionData::MODE_FAN); // Only Shaman
			break;

#ifdef ENABLE_COSTUME_WEAPON
		case CItemData::COSTUME_WEAPON_BELL:
#endif
		case CItemData::WEAPON_BELL:
			SetMotionMode(CRaceMotionData::MODE_BELL); // Only Shaman
			break;

		case CItemData::WEAPON_ARROW:
		default:
			SetMotionMode(CRaceMotionData::MODE_GENERAL);
			break;
		}
	}

	if (isLoop)
		m_GraphicThingInstance.InterceptLoopMotion(dwMotIndex);
	else
		m_GraphicThingInstance.InterceptOnceMotion(dwMotIndex);

	RefreshActorInstance();
}
