PyObject * itemGetAffect(PyObject * poSelf, PyObject * poArgs)
{
	int iValueIndex;
	if (!PyTuple_GetInteger(poArgs, 0, &iValueIndex))
		return Py_BadArgument();

	CItemData * pItemData = CItemManager::Instance().GetSelectedItemDataPointer();
	if (!pItemData)
		return Py_BuildException("Not yet select item data");

	CItemData::TItemApply ItemApply;
	if (!pItemData->GetApply(iValueIndex, &ItemApply))
		return Py_BuildException();

	if ((CItemData::APPLY_ATT_SPEED == ItemApply.bType) && (CItemData::ITEM_TYPE_WEAPON == pItemData->GetType()) && (CItemData::WEAPON_TWO_HANDED == pItemData->GetSubType() 
	#ifdef ENABLE_COSTUME_WEAPON
	|| CItemData::COSTUME_WEAPON_TWO_HANDED == pItemData->GetSubType()
	#endif
	))
	{
		ItemApply.lValue -= TWOHANDED_WEWAPON_ATT_SPEED_DECREASE_VALUE;
	}

	return Py_BuildValue("ii", ItemApply.bType, ItemApply.lValue);
}

void initItem()
{
	
[..]
#ifdef ENABLE_COSTUME_SYSTEM
	PyModule_AddIntConstant(poModule, "ITEM_TYPE_COSTUME",			CItemData::ITEM_TYPE_COSTUME);

	// Item Sub Type
	PyModule_AddIntConstant(poModule, "COSTUME_TYPE_BODY",			CItemData::COSTUME_BODY);
	PyModule_AddIntConstant(poModule, "COSTUME_TYPE_HAIR",			CItemData::COSTUME_HAIR);
	#ifdef ENABLE_COSTUME_WEAPON
	PyModule_AddIntConstant(poModule, "COSTUME_TYPE_WEAPON_SWORD",	CItemData::COSTUME_WEAPON_SWORD);
	PyModule_AddIntConstant(poModule, "COSTUME_TYPE_WEAPON_DAGGER", CItemData::COSTUME_WEAPON_DAGGER);
	PyModule_AddIntConstant(poModule, "COSTUME_TYPE_WEAPON_BOW",	CItemData::COSTUME_WEAPON_BOW);
	PyModule_AddIntConstant(poModule, "COSTUME_TYPE_WEAPON_TWOHAND",CItemData::COSTUME_WEAPON_TWO_HANDED);
	PyModule_AddIntConstant(poModule, "COSTUME_TYPE_WEAPON_BELL",	CItemData::COSTUME_WEAPON_BELL);
	PyModule_AddIntConstant(poModule, "COSTUME_TYPE_WEAPON_FAN",	CItemData::COSTUME_WEAPON_FAN);
	PyModule_AddIntConstant(poModule, "COSTUME_SLOT_WEAPON",		c_Costume_Slot_Weapon);
	#endif
	// �κ��丮 �� ���â������ ���� ��ȣ
	PyModule_AddIntConstant(poModule, "COSTUME_SLOT_START",			c_Costume_Slot_Start);
	PyModule_AddIntConstant(poModule, "COSTUME_SLOT_COUNT",			c_Costume_Slot_Count);
	PyModule_AddIntConstant(poModule, "COSTUME_SLOT_BODY",			c_Costume_Slot_Body);
	PyModule_AddIntConstant(poModule, "COSTUME_SLOT_HAIR",			c_Costume_Slot_Hair);
	PyModule_AddIntConstant(poModule, "COSTUME_SLOT_END",			c_Costume_Slot_End);
#endif
[..]

}
