#ifdef ENABLE_COSTUME_SYSTEM
	const DWORD c_Costume_Slot_Start	= c_Equipment_Start + 19;	// [ÁÖÀÇ] ¼ýÀÚ(19) ÇÏµåÄÚµù ÁÖÀÇ. ÇöÀç ¼­¹ö¿¡¼­ ÄÚ½ºÃõ ½½·ÔÀº 19ºÎÅÍÀÓ. ¼­¹ö common/length.h ÆÄÀÏÀÇ EWearPositions ¿­°ÅÇü Âü°í.
	const DWORD	c_Costume_Slot_Body		= c_Costume_Slot_Start + 0;
	const DWORD	c_Costume_Slot_Hair		= c_Costume_Slot_Start + 1;
	#ifdef ENABLE_COSTUME_WEAPON
	const DWORD	c_Costume_Slot_Weapon		= c_Costume_Slot_Start + 1;
	const DWORD c_Costume_Slot_Count	= 3;
	#else
	const DWORD c_Costume_Slot_Count	= 2;
	#endif
	const DWORD c_Costume_Slot_End		= c_Costume_Slot_Start + c_Costume_Slot_Count;
#endif
[..]
#ifdef ENABLE_NEW_EQUIPMENT_SYSTEM
	#ifdef ENABLE_COSTUME_WEAPON
	const DWORD c_New_Equipment_Start = c_Equipment_Start + 22;
	#else
	const DWORD c_New_Equipment_Start = c_Equipment_Start + 21;
	#endif
#endif