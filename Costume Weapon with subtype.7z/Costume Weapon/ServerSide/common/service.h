[..]
#define COSTUME_WEAPON // Enable costume weapon
[..]