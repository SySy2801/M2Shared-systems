int CItem::FindEquipCell(LPCHARACTER ch, int iCandidateCell)
{
	[..]
	
	else if (GetType() == ITEM_COSTUME)
	{
		if (GetSubType() == COSTUME_BODY)
			return WEAR_COSTUME_BODY;
		else if (GetSubType() == COSTUME_HAIR)
			return WEAR_COSTUME_HAIR;
		#ifdef COSTUME_WEAPON
		else if (GetSubType() == COSTUME_WEAPON_SWORD ||
			GetSubType() == COSTUME_WEAPON_DAGGER ||
			GetSubType() == COSTUME_WEAPON_BOW ||
			GetSubType() == COSTUME_WEAPON_TWO_HANDED ||
			GetSubType() == COSTUME_WEAPON_BELL ||
			GetSubType() == COSTUME_WEAPON_FAN ||
			GetSubType() == COSTUME_WEAPON_CLAW)
			return WEAR_COSTUME_WEAPON;
#endif
	}
	else if (GetType() == ITEM_RING)
	{
		if (ch->GetWear(WEAR_RING1))
			return WEAR_RING2;
		else
			return WEAR_RING1;
	}
	[..]
}

void CItem::ModifyPoints(bool bAdd)
{
	[..]

	switch (m_pProto->bType)
	{
		[..]

	case ITEM_WEAPON:
	{
#ifdef COSTUME_WEAPON
		if (0 != m_pOwner->GetWear(WEAR_COSTUME_WEAPON))
			break;
#endif
			if (bAdd)
			{
				if (m_wCell == INVENTORY_MAX_NUM + WEAR_WEAPON)
					m_pOwner->SetPart(PART_WEAPON, GetVnum());
			}
			else
			{
				if (m_wCell == INVENTORY_MAX_NUM + WEAR_WEAPON)
					m_pOwner->SetPart(PART_WEAPON, m_pOwner->GetOriginalPart(PART_WEAPON));
			}
		
			break;
		[..]
		// ÄÚ˝şĂő ľĆŔĚĹŰ ŔÔľúŔ» ¶§ Äł¸ŻĹÍ parts Á¤ş¸ ĽĽĆĂ. ±âÁ¸ ˝şĹ¸ŔĎ´ë·Î Ăß°ˇÇÔ..
		case ITEM_COSTUME:
			{
				DWORD toSetValue = this->GetVnum();
				EParts toSetPart = PART_MAX_NUM;

				// °©żĘ ÄÚ˝şĂő
				if (GetSubType() == COSTUME_BODY)
				{				
					toSetPart = PART_MAIN;

					if (false == bAdd)
					{
						// ÄÚ˝şĂő °©żĘŔ» ąţľúŔ» ¶§ żř·ˇ °©żĘŔ» ŔÔ°í ŔÖľú´Ů¸é ±× °©żĘŔ¸·Î look ĽĽĆĂ, ŔÔÁö ľĘľŇ´Ů¸é default look
						const CItem* pArmor = m_pOwner->GetWear(WEAR_BODY);
						toSetValue = (NULL != pArmor) ? pArmor->GetVnum() : m_pOwner->GetOriginalPart(PART_MAIN);						
					}
					
				}

				// Çěľî ÄÚ˝şĂő
				else if (GetSubType() == COSTUME_HAIR)
				{
					toSetPart = PART_HAIR;

					// ÄÚ˝şĂő Çěľî´Â shape°ŞŔ» item protoŔÇ value3żˇ ĽĽĆĂÇĎµµ·Ď ÇÔ. ĆŻş°ÇŃ ŔĚŔŻ´Â ľř°í ±âÁ¸ °©żĘ(ARMOR_BODY)ŔÇ shape°ŞŔĚ ÇÁ·ÎĹäŔÇ value3żˇ ŔÖľîĽ­ Çěľîµµ °°ŔĚ value3Ŕ¸·Î ÇÔ.
					// [NOTE] °©żĘŔş ľĆŔĚĹŰ vnumŔ» ş¸ł»°í Çěľî´Â shape(value3)°ŞŔ» ş¸ł»´Â ŔĚŔŻ´Â.. ±âÁ¸ ˝Ă˝şĹŰŔĚ ±×·¸°Ô µÇľîŔÖŔ˝...
					toSetValue = (true == bAdd) ? this->GetValue(3) : 0;
				}
				#ifdef COSTUME_WEAPON
				else if (GetSubType() == COSTUME_WEAPON_SWORD ||
					GetSubType() == COSTUME_WEAPON_DAGGER ||
					GetSubType() == COSTUME_WEAPON_BOW ||
					GetSubType() == COSTUME_WEAPON_TWO_HANDED ||
					GetSubType() == COSTUME_WEAPON_BELL ||
					GetSubType() == COSTUME_WEAPON_FAN ||
					GetSubType() == COSTUME_WEAPON_CLAW)
				{
					toSetPart = PART_WEAPON;
					if (false == bAdd)
					{
						// 코1oAo 갑?EA?1???때 ?o? 갑?EA?A蹈?A?駭U면 그 갑?EA막?look 11AA, A讀?3E3O?면 default look
						const CItem* pWeapon = m_pOwner->GetWear(WEAR_WEAPON);
						toSetValue = (NULL != pWeapon) ? pWeapon->GetVnum() : m_pOwner->GetOriginalPart(PART_WEAPON);

					}
				}
		#endif
				if (PART_MAX_NUM != toSetPart)
				{
					m_pOwner->SetPart((BYTE)toSetPart, toSetValue);
					m_pOwner->UpdatePacket();
				}
			}
		[..]
	}
}
