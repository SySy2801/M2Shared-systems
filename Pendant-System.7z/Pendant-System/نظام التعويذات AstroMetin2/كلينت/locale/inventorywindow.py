'''���� ��'''
"name" : "Equipment_Base",
'''��� ���� ������ ��� ��� '''
	"image" : "locale/ae/ui/inventory_astro.tga",

'''���'''
										{"index":item.EQUIPMENT_PENDANT, "x":3, "y":106, "width":32, "height":32},										
'''���'''
										{"index":item.EQUIPMENT_BELT, "x":39, "y":106, "width":32, "height":32},

'''��� ��������� ���� �� ����� ������'''
				## Equipment Slot
				{
					"name" : "Equipment_Base",
					"type" : "expanded_image",

					"x" : 10,
					"y" : 33,

					"image" : "locale/ae/ui/inventory_astro.tga",

					"children" :
					(

						{
							"name" : "EquipmentSlot",
							"type" : "slot",

							"x" : 3,
							"y" : 3,

							"width" : 150,
							"height" : 182,

							"slot" : (
										{"index":EQUIPMENT_START_INDEX+0, "x":39, "y":37, "width":32, "height":64},
                                        {"index":EQUIPMENT_START_INDEX+1, "x":39, "y":2, "width":32, "height":32},
                                        {"index":EQUIPMENT_START_INDEX+2, "x":39, "y":145, "width":32, "height":32},
                                        {"index":EQUIPMENT_START_INDEX+3, "x":75, "y":67, "width":32, "height":32},
                                        {"index":EQUIPMENT_START_INDEX+4, "x":3, "y":3, "width":32, "height":96},
                                        {"index":EQUIPMENT_START_INDEX+5, "x":114, "y":67, "width":32, "height":32},
                                        {"index":EQUIPMENT_START_INDEX+6, "x":114, "y":35, "width":32, "height":32},
                                        {"index":EQUIPMENT_START_INDEX+7, "x":2, "y":145, "width":32, "height":32},
                                        {"index":EQUIPMENT_START_INDEX+8, "x":75, "y":145, "width":32, "height":32},
                                        {"index":EQUIPMENT_START_INDEX+9, "x":114, "y":2, "width":32, "height":32},
                                        {"index":EQUIPMENT_START_INDEX+10, "x":75, "y":35, "width":32, "height":32},
										{"index":item.EQUIPMENT_BELT, "x":39, "y":106, "width":32, "height":32},
										{"index":item.EQUIPMENT_PENDANT, "x":3, "y":106, "width":32, "height":32},										
									),