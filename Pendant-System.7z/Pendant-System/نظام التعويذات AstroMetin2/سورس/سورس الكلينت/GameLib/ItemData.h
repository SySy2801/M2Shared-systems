//���� �� :
		enum EArmorSubTypes
//���:
			ARMOR_PENDANT,
//����� ��� ����� :
		enum EArmorSubTypes
		{
			ARMOR_BODY,
			ARMOR_HEAD,
			ARMOR_SHIELD,
			ARMOR_WRIST,
			ARMOR_FOOTS,
		    ARMOR_NECK,
			ARMOR_EAR,
			ARMOR_PENDANT,			
			ARMOR_NUM_TYPES
		};
//���� �� :
		enum EWearPositions
//���:
			WEAR_PENDANT,        // 11
//����� ��� �����:(����)
		enum EWearPositions
		{
			WEAR_BODY,          // 0
			WEAR_HEAD,          // 1
			WEAR_FOOTS,         // 2
			WEAR_WRIST,         // 3
			WEAR_WEAPON,        // 4
			WEAR_NECK,          // 5
			WEAR_EAR,           // 6
			WEAR_UNIQUE1,       // 7
			WEAR_UNIQUE2,       // 8
			WEAR_ARROW,         // 9
			WEAR_SHIELD,        // 10
			WEAR_COSTUME_HAIR,
#ifdef ENABLE_SASH_SYSTEM
			WEAR_COSTUME_SASH,
#endif
#ifdef ENABLE_COSTUME_WEAPON_SYSTEM
			WEAR_COSTUME_WEAPON,
#endif
			WEAR_PENDANT,        // 11
			WEAR_MAX_NUM,
		};
//���� �� :
		enum EItemWearableFlag
//��� :
			WEARABLE_PENDANT     = (1 << 10),
//����� �� ����� :
		enum EItemWearableFlag
		{
			WEARABLE_BODY       = (1 << 0),
			WEARABLE_HEAD       = (1 << 1),
			WEARABLE_FOOTS      = (1 << 2),
			WEARABLE_WRIST      = (1 << 3),
			WEARABLE_WEAPON     = (1 << 4),
			WEARABLE_NECK       = (1 << 5),
			WEARABLE_EAR        = (1 << 6),
			WEARABLE_UNIQUE     = (1 << 7),
			WEARABLE_SHIELD     = (1 << 8),
			WEARABLE_ARROW      = (1 << 9),
			WEARABLE_PENDANT     = (1 << 10),			
		};			