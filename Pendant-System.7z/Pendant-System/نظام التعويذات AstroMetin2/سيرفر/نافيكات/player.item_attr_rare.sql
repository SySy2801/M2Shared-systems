ALTER TABLE `item_attr_rare`
ADD COLUMN `pendant` varchar(100) NOT NULL DEFAULT 0 AFTER `ear`;

